// Shared helpers used across all pages.

async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || 'GET',
    headers: options.body ? { 'Content-Type': 'application/json' } : {},
    body: options.body ? JSON.stringify(options.body) : undefined,
    credentials: 'same-origin',
  });
  let data = {};
  try { data = await res.json(); } catch {}
  if (!res.ok) throw new Error(data.error || 'وقع خطأ');
  return data;
}

function escapeHtml(str) {
  return (str || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'دابا';
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} د`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} سا`;
  if (diff < 2592000) return `منذ ${Math.floor(diff / 86400)} يوم`;
  return new Date(iso).toLocaleDateString('ar-MA');
}

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2800);
}

function initials(name) {
  return (name || '?').trim().slice(0, 1).toUpperCase();
}

function avatarHtml(user, size = '') {
  const cls = 'avatar' + (size ? ' ' + size : '');
  if (user && user.avatar) {
    return `<div class="${cls}"><img src="${user.avatar}" alt=""></div>`;
  }
  return `<div class="${cls}">${initials(user ? (user.displayName || user.authorDisplayName) : '?')}</div>`;
}

function verifiedBadge(isVerified) {
  return isVerified
    ? `<span class="badge-check" title="حساب موثّق">✓</span>`
    : '';
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

let CURRENT_USER = null;

async function requireAuth() {
  try {
    const { user } = await api('/api/me');
    CURRENT_USER = user;
    return user;
  } catch {
    window.location.href = '/index.html';
    return null;
  }
}

async function logout() {
  await api('/api/logout', { method: 'POST' });
  window.location.href = '/index.html';
}

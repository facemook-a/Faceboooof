const titles = {
  dashboard: 'لوحة القيادة',
  verify: 'طلبات التوثيق',
  users: 'المستخدمين',
  posts: 'المنشورات',
};

let currentTab = 'dashboard';

function setActiveTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.admin-sidebar a[data-tab]').forEach((a) => {
    a.classList.toggle('active', a.dataset.tab === tab);
  });
  document.getElementById('pageTitle').textContent = titles[tab];
  render();
}

document.querySelectorAll('.admin-sidebar a[data-tab]').forEach((a) => {
  a.addEventListener('click', (e) => {
    e.preventDefault();
    setActiveTab(a.dataset.tab);
  });
});

document.getElementById('logoutBtn').onclick = (e) => { e.preventDefault(); logout(); };

async function render() {
  const content = document.getElementById('content');
  const searchWrap = document.getElementById('searchWrap');
  searchWrap.innerHTML = '';
  content.innerHTML = '<div class="loading-ring"></div>';

  if (currentTab === 'dashboard') return renderDashboard(content);
  if (currentTab === 'verify') return renderVerify(content);
  if (currentTab === 'users') return renderUsers(content, searchWrap);
  if (currentTab === 'posts') return renderPosts(content, searchWrap);
}

async function renderDashboard(content) {
  try {
    const s = await api('/api/admin/stats');
    content.innerHTML = `
      <div class="stat-cards">
        <div class="stat-card"><div class="num">${s.totalUsers}</div><div class="lbl">مجموع المستخدمين</div></div>
        <div class="stat-card"><div class="num">${s.totalPosts}</div><div class="lbl">مجموع المنشورات</div></div>
        <div class="stat-card"><div class="num">${s.verifiedUsers}</div><div class="lbl">حسابات موثّقة ✔️</div></div>
        <div class="stat-card"><div class="num">${s.pendingVerifications}</div><div class="lbl">طلبات فالانتظار</div></div>
        <div class="stat-card"><div class="num">${s.bannedUsers}</div><div class="lbl">حسابات محظورة</div></div>
      </div>
      <div class="side-card">
        <h3>مرحبا بيك فلوحة إدارة "حلقة" 🌙</h3>
        <div style="font-size:14px;color:#4d4638;line-height:1.8">
          من هنا تقدر توافق على طلبات الشارة الزرقاء، تدير المستخدمين (حظر/إلغاء حظر)، وتراقب المنشورات المنشورة فالموقع.
        </div>
      </div>
    `;
  } catch (err) { content.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`; }
}

async function renderVerify(content) {
  try {
    const { requests } = await api('/api/admin/verify-requests');
    if (requests.length === 0) {
      content.innerHTML = `<div class="empty-state">مافيش طلبات توثيق دابا</div>`;
      return;
    }
    content.innerHTML = requests.map(r => `
      <div class="request-card" data-id="${r.id}">
        <div class="top">
          <div>
            <b>${escapeHtml(r.displayName)}</b> <span style="color:#85795f">@${escapeHtml(r.username)}</span>
          </div>
          <span class="pill pill-${r.status === 'pending' ? 'pending' : r.status === 'approved' ? 'approved' : 'rejected'}">
            ${r.status === 'pending' ? 'فالانتظار' : r.status === 'approved' ? 'توافق عليه' : 'تم رفضه'}
          </span>
        </div>
        <div class="reason">${escapeHtml(r.reason)}</div>
        ${r.document ? `<img class="doc-img" src="${r.document}">` : ''}
        <div style="font-size:12px;color:#a29a82">${timeAgo(r.createdAt)}</div>
        ${r.status === 'pending' ? `
        <div class="request-actions">
          <button class="btn btn-primary btn-sm approve-btn">✔️ وافق</button>
          <button class="btn btn-danger btn-sm reject-btn">✕ رفض</button>
        </div>` : ''}
      </div>
    `).join('');

    content.querySelectorAll('.approve-btn').forEach(btn => btn.onclick = async () => {
      const id = btn.closest('.request-card').dataset.id;
      try { await api(`/api/admin/verify-requests/${id}/approve`, { method: 'POST' }); toast('تم التوثيق ✔️'); renderVerify(content); }
      catch (err) { toast(err.message); }
    });
    content.querySelectorAll('.reject-btn').forEach(btn => btn.onclick = async () => {
      const id = btn.closest('.request-card').dataset.id;
      try { await api(`/api/admin/verify-requests/${id}/reject`, { method: 'POST', body: {} }); toast('تم الرفض'); renderVerify(content); }
      catch (err) { toast(err.message); }
    });
  } catch (err) { content.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`; }
}

async function renderUsers(content, searchWrap) {
  searchWrap.innerHTML = `<div class="search-box"><input id="userSearch" placeholder="قلب على مستخدم..."></div>`;
  async function load(q) {
    const { users } = await api('/api/admin/users' + (q ? '?q=' + encodeURIComponent(q) : ''));
    content.innerHTML = `
      <table>
        <thead><tr><th>الاسم</th><th>المستخدم</th><th>الحالة</th><th>الدور</th><th>إجراءات</th></tr></thead>
        <tbody>
        ${users.map(u => `
          <tr data-id="${u.id}">
            <td>${escapeHtml(u.displayName)} ${u.verified ? '✔️' : ''}</td>
            <td>@${escapeHtml(u.username)}</td>
            <td>${u.banned ? '<span class="banned-badge">محظور</span>' : '<span style="color:var(--good)">نشيط</span>'}</td>
            <td><span class="role-badge ${u.role}">${u.role === 'admin' ? 'مشرف' : 'مستخدم'}</span></td>
            <td>
              ${u.banned
                ? `<button class="btn btn-ghost btn-sm unban-btn">إلغاء الحظر</button>`
                : `<button class="btn btn-danger btn-sm ban-btn">حظر</button>`}
              ${u.role !== 'admin' ? `<button class="btn btn-ghost btn-sm mkadmin-btn">ترقية لمشرف</button>` : ''}
            </td>
          </tr>
        `).join('')}
        </tbody>
      </table>
    `;
    content.querySelectorAll('.ban-btn').forEach(b => b.onclick = async () => {
      if (!confirm('واخا تحظر هاد المستخدم؟')) return;
      await api(`/api/admin/users/${b.closest('tr').dataset.id}/ban`, { method: 'POST' });
      load(document.getElementById('userSearch').value);
    });
    content.querySelectorAll('.unban-btn').forEach(b => b.onclick = async () => {
      await api(`/api/admin/users/${b.closest('tr').dataset.id}/unban`, { method: 'POST' });
      load(document.getElementById('userSearch').value);
    });
    content.querySelectorAll('.mkadmin-btn').forEach(b => b.onclick = async () => {
      if (!confirm('واخا ترقي هاد المستخدم لمشرف؟ غادي يقدر يدخل للوحة الإدارة.')) return;
      await api(`/api/admin/users/${b.closest('tr').dataset.id}/make-admin`, { method: 'POST' });
      load(document.getElementById('userSearch').value);
    });
  }
  load();
  document.getElementById('userSearch').addEventListener('input', (e) => load(e.target.value));
}

async function renderPosts(content, searchWrap) {
  searchWrap.innerHTML = `<div class="search-box"><input id="postSearch" placeholder="قلب فالمنشورات..."></div>`;
  async function load(q) {
    const { posts } = await api('/api/admin/posts' + (q ? '?q=' + encodeURIComponent(q) : ''));
    if (posts.length === 0) { content.innerHTML = `<div class="empty-state">مافيش نتائج</div>`; return; }
    content.innerHTML = posts.map(p => `
      <div class="request-card" data-id="${p.id}">
        <div class="top">
          <b>@${escapeHtml(p.authorUsername)}</b>
          <button class="btn btn-danger btn-sm del-btn">🗑️ حذف</button>
        </div>
        <div class="reason">${escapeHtml(p.content || '(بلا نص)')}</div>
        ${p.image ? `<img class="doc-img" src="${p.image}">` : ''}
        <div style="font-size:12px;color:#a29a82">${timeAgo(p.createdAt)} · ${p.likes.length} إعجاب · ${p.comments.length} تعليق</div>
      </div>
    `).join('');
    content.querySelectorAll('.del-btn').forEach(b => b.onclick = async () => {
      if (!confirm('واخا تمسح هاد المنشور؟')) return;
      await api(`/api/admin/posts/${b.closest('.request-card').dataset.id}`, { method: 'DELETE' });
      load(document.getElementById('postSearch').value);
    });
  }
  load();
  document.getElementById('postSearch').addEventListener('input', (e) => load(e.target.value));
}

(async () => {
  try {
    const { user } = await api('/api/me');
    if (user.role !== 'admin') { window.location.href = '/feed.html'; return; }
    CURRENT_USER = user;
    render();
  } catch {
    window.location.href = '/index.html';
  }
})();
